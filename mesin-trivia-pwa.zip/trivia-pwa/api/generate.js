// Fungsi serverless (Vercel). API key disimpan di server, tidak pernah dikirim ke browser.
const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5';
const MAX_PROMPT = 4000;

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' });

  // Kode akses opsional: cegah orang asing memakai kuota API Anda.
  const code = process.env.APP_PASSCODE;
  if (code && req.headers['x-access-code'] !== code) return res.status(401).json({ error: 'unauthorized' });

  const prompt = req.body && req.body.prompt;
  if (typeof prompt !== 'string' || !prompt.trim() || prompt.length > MAX_PROMPT)
    return res.status(400).json({ error: 'bad_request' });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(500).json({ error: 'missing_api_key' });

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 6000,
        system: 'Kamu pembuat trivia dan kuis. Balas hanya dengan JSON valid sesuai format yang diminta, tanpa teks lain.',
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    if (r.status === 429) return res.status(429).json({ error: 'rate_limited' });
    if (!r.ok) return res.status(502).json({ error: 'upstream', status: r.status });

    const out = await r.json();
    const text = (out.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
    const a = text.indexOf('['), b = text.lastIndexOf(']');
    if (a < 0 || b < a) return res.status(502).json({ error: 'bad_output' });
    return res.status(200).json({ data: JSON.parse(text.slice(a, b + 1)) });
  } catch (e) {
    return res.status(502).json({ error: 'bad_output' });
  }
};
