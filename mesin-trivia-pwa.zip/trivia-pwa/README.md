# Mesin Trivia (PWA)

Aplikasi web yang bisa dipasang ke layar utama HP. Ketik topik, dapatkan trivia atau kuis pilihan ganda (mudah/sedang/sulit).

## Isi paket

- `public/` : tampilan aplikasi (index.html), manifest, service worker, ikon
- `api/generate.js` : server kecil yang memanggil Claude. API key hanya ada di sini
- `vercel.json` : pengaturan Vercel (batas waktu fungsi 60 detik)
- `.env.example` : contoh variabel lingkungan

## Yang perlu disiapkan

1. API key Anthropic dari console.anthropic.com (berbayar sesuai pemakaian).
2. Akun Vercel (gratis) dan akun GitHub (gratis).

## Cara deploy (lewat GitHub + Vercel)

1. Ekstrak folder ini, lalu unggah ke repository GitHub baru (privat boleh).
2. Di vercel.com pilih Add New > Project, pilih repository tadi. Biarkan pengaturan bawaan.
3. Sebelum menekan Deploy, buka Environment Variables dan isi:
   - `ANTHROPIC_API_KEY` = API key Anda
   - `APP_PASSCODE` = kode rahasia pilihan Anda (sangat disarankan, supaya orang asing tidak memakai kuota Anda)
   - `ANTHROPIC_MODEL` (opsional) = nama model. Bawaannya `claude-sonnet-4-5`. Model yang lebih kecil lebih murah.
4. Tekan Deploy. Anda akan mendapat alamat seperti `https://nama-proyek.vercel.app`.

## Cara memasang di HP

- Android (Chrome): buka alamatnya, menu titik tiga, Instal aplikasi / Tambahkan ke layar utama.
- iPhone (Safari): buka alamatnya, tombol Bagikan, Tambah ke Layar Utama.

Pertama kali dipakai, aplikasi akan meminta Kode akses. Isi sama dengan `APP_PASSCODE`; kode tersimpan di HP itu.

## Uji di komputer

```
npm i -g vercel
cp .env.example .env     # lalu isi nilainya
vercel dev
```

## Catatan

- Trivia dibuat AI, jadi periksa dulu faktanya sebelum dipakai untuk kuis resmi.
- Tanpa `APP_PASSCODE`, siapa pun yang tahu alamatnya bisa memakai API key Anda. Jangan dikosongkan.
- Layar tampil offline, tetapi membuat trivia tetap butuh internet.
